import express from "express";
import bodyParser from "body-parser";
import mongoose from "mongoose";
import dotenv from "dotenv";
import dataFetch from "./routes/dataFetch";
import cors from "cors";

dotenv.config();

const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true })); // Add this line to support URL-encoded bodies
app.use(cors());
const PORT = process.env.PORT || 3000; // Use process.env.PORT to allow for deployment on platforms like Heroku

try {
  mongoose.connect(process.env.DATABASE_URL);
  const connection = mongoose.connection;
  connection.once("open", () => {
    console.log("Successfully connected to the database");
  });
} catch (error) {
  console.error("Could not connect to the database:", error);
}

app.listen(PORT, () => console.log("Server is running on port:", PORT));

// Test route
app.get("/", (req, res) => {
  res.send("Hello, I am your MERN stack server!");
});

// Add your dataFetch route
app.use("/data", dataFetch);

// Add a catch-all route for handling unknown routes or serving the React frontend
// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname
