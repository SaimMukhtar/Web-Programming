import mongoose from "mongoose";
const StudentAttendaneSchema = new mongoose.Schema({
 id: {
    type: String,
    required: true,
  },
  subject: {
    type: String,
    required: true,
  },
   section: {
    type: String,
    required: true,
  },
  mark: {
    type: Boolean,
    required: true,
  },date: {
    type: String,
    required: true,
  },
});

export default mongoose.model("StudentAttendanceData", StudentAttendaneSchema);
