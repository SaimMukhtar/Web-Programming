import express from "express";
import mongoose from "mongoose";
import Login from "../modal/attendance";
import Student from "../modal/student";
import StudentAttendanceData from "../modal/studentAttendance"

const router = express.Router();

// Create one
router.post("/dataSend", async (req, res) => {
  const register = new Login({
    username: req.body.username,
    password: req.body.password,
  });

  try {
    const Newregister = await register.save();
    res.status(201).json(Newregister);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

//Get based on username and see if password matches

router.post("/dataCheck", async (req, res) => {
 
    const usernameValue= req.body.username;
    const passwordValue = req.body.password;
// console.log(usernameValue);
// console.log(passwordValue);


  try {
    const usernameID = await Login.find({username: usernameValue });
    // console.log(usernameID);
    if(usernameID[0].username == usernameValue && usernameID[0].password == passwordValue){
        res.send(true)
    }else{
        res.send(false)
    }

} catch (err) {
    res.status(400).json({ message: err.message });
  }
});

//adding a new student
router.post("/dataSendStudent", async (req, res) => {
  const register = new Student({
    id: req.body.id,
    name: req.body.name,
    section: req.body.section,
    subject: req.body.subject,
  });
  console.log(register);
  
  try {
    const Newregister = await register.save();
    res.status(201).json(Newregister);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});
type MAPTYPE = {
    id:string,
    date:string,
}
//sending the attendance data to the database
router.post("/dataSendStudentAttendance", async (req, res) => {
    const { updatedData } = req.body;
    console.log(updatedData);
    
    // console.log(updatedData);
    // const dataToInsert = updatedData.map(({ id, date, ...rest }:MAPTYPE) => ({
    //   customId: `${id}-${date}`, // Generate a custom ID
    //   ...rest,
    // }));
    // for (const item of updatedData) {
    //    await StudentAttendanceData.create(item)
    //     return null
    // }
try{
   const insertedData = await StudentAttendanceData.insertMany(updatedData);
     res.status(201).json({ message: "Attendance data saved successfully", data: insertedData });
  } catch (error) {
    console.error("Error saving attendance data:", error);
    res.status(500).json({ error: "An error occurred while saving attendance data" });
  }
//   try {
//     const Newregister = await register.save();
//     res.status(201).json(Newregister);
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
});

//getting the data
router.get("/data", async (req, res) => {
  try {
    const allToDoItems = await Login.find({});
    console.log(allToDoItems);
    
    res.status(200).json(allToDoItems);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


//getting the data from the database based on two contraints(subject, section):
router.post("/dataStudentGrab", async (req, res) => {
    console.log("hello");
    
    const subjectValue= req.body.subject;
    const sectionValue = req.body.section;
    console.log(subjectValue);
    console.log(sectionValue);


  try {
    const allUsers = await Student.find({subject: subjectValue, section: sectionValue  });
    console.log(allUsers);
    
    // console.log(usernameID);
    if(allUsers.length > 0){
        res.send(allUsers)
    }

    } catch (err) {
    res.status(400).json({ message: err.message });
    }
    });


// Get all
// router.get("/data", async (req, res) => {
//   try {
//     const allToDoItems = await Login.find({});
//     res.status(200).json(allToDoItems);

//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

//delete

router.delete('/delete/:id', async (req, res) => {
  const todoId = req.params.id;
  try {
    const deletedTodo = await Login.deleteOne({ id: todoId });
    console.log(deletedTodo);
     

    if (!deletedTodo) {
      return res.status(404).json({ error: 'Todo item not found' });
    }

    res.json({ success: true, todo: deletedTodo });
  } catch (error) {
    console.error('Error deleting todo:', error);
    res.status(500).json({ error: 'Failed to delete the todo item' });
  }
});

//Update check 


// Assuming you have a route to update a todo item by its ID

router.patch('/update/:id', async (req, res) => {
  let todoId = req.params.id;
    // todoId = TODOLIST.findOne({ _id: ObjectId(todoId) })
  try {
    // Find the todo item by its ID
    const todoItem = await Login.find({id: todoId});
    const todoItemObj = todoItem[0]
    // const newtodoItem =  await TODOLIST.findByIdAndUpdate(todoItem[0]._id,  )
    console.log(todoItem);

  
    if (!todoItem) {
      return res.status(404).json({ error: 'Todo item not found' });
    }

    // Toggle the 'check' value (from true to false and vice versa)
    // todoItemObj.check = !todoItemObj.check;
    
    console.log(todoItemObj);

    // Save the updated todo item
     const updatedTodo = await todoItemObj.save();
    res.json(updatedTodo);
  } catch (error) {
    console.error('Error updating todo:', error);
    res.status(500).json({ error: 'Failed to update the todo item' });
  }
});


router.patch('/updated/:id', async (req, res) => {
  let todoId = req.params.id;
    // todoId = TODOLIST.findOne({ _id: ObjectId(todoId) })
  try {
    // Find the todo item by its ID
    const todoItem = await Login.find({id: todoId});
    const todoItemObj = todoItem[0]
    // const newtodoItem =  await TODOLIST.findByIdAndUpdate(todoItem[0]._id,  )
    console.log(todoItem);
    
    if (req.body.title) {
    //   todoItemObj.title = req.body.title;
    }
    if (!todoItem) {
      return res.status(404).json({ error: 'Todo item not found' });
    }

    // Toggle the 'check' value (from true to false and vice versa)
  
    
    console.log(todoItemObj);

    // Save the updated todo item
     const updatedTodo = await todoItemObj.save();
    res.json(updatedTodo);
  } catch (error) {
    console.error('Error updating todo:', error);
    res.status(500).json({ error: 'Failed to update the todo item' });
  }
});


export default router;


// router.get("/", async (req, res) => {
//   try {
//     const suscriber = await Suscriber.find();

//     res.json(suscriber);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// //Get one
// router.get("/:id", getSubscriber, (req, res) => {
//   // Check if req.suscriber exists before accessing its properties
//   if (req.suscriber) {
//     res.send(req.suscriber.name); 
//   } else {
//     // Respond with an appropriate message if the subscriber was not found
//     res.status(404).json({ message: "Subscriber not found" });
//   }
// });



// //Update one
// router.put("/:id", (req, res) => {
//   res.send("Hello, World!");
// });

// //Delete one
// router.delete("/:id", (req, res) => {
//   res.send("Hello, World!");
// });

// async function getSubscriber(req, res, next) {
//   try {
//     const suscriber = await Suscriber.findById(req.params.id);
//     if (!suscriber) {
//       return res.status(404).json({ message: "Can not find the user" });
//     }
//     res.suscriber = suscriber;
//     next();
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// }

// // router.get("/hello", (req, res) => {
// //   res.json({ message: "Hello, World!" });
// // });


