import DashboardTemplate from "../../Templates/DashboardTemplate/DashboardTemplate";
import PageTrackerTemplate from "../../Templates/PageTrackerTemplate/PageTrackerTemplate";
import MenuTemplate from "../../Templates/MenuTemplate/MenuTemplate";
// import SubjectDropDown from "../../components/common/SubjectDropDown/SubjectDropDown";
import CustomDatePicker from "../../components/Date/CustomDatePicker";
import Button from "../../components/common/Button/Button";
import { Link, Outlet } from "react-router-dom";

function Test() {
  // const items = ["Item 1", "Item 2", "Item 3", "Item 4"];
  return (
    <div>
      <DashboardTemplate>
        <PageTrackerTemplate>
          <MenuTemplate>
            {/* <SubjectDropDown upper={"Subject"} items={items} /> */}
            {/* <SubjectDropDown upper={"Section"} items={items} /> */}
            <CustomDatePicker upper={"Date"} />
            <nav>
              <Link to="Sheet">
                <Button name={"Generate Sheet"} />
              </Link>
            </nav>
          </MenuTemplate>

          <Outlet />
        </PageTrackerTemplate>
      </DashboardTemplate>
    </div>
  );
}

export default Test;
