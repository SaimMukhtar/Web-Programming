// import Header from "../../components/Header/Header";
import HeaderLogin from "../../components/Header/HeaderLogin";
import LoginForm from "../../components/Login/LoginForm/LoginForm";
import LoginContent from "../../components/LoginContent/LoginContent";
import styles from "./LoginPage.module.css";

function LoginPage() {
  return (
    <div>
      <HeaderLogin />
      <div className={styles.loginPageContainer}>
        <LoginContent />
        <div>
          <LoginForm />
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
