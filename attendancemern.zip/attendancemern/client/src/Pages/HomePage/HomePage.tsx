import DashboardTemplate from "../../Templates/DashboardTemplate/DashboardTemplate";

function HomePage() {
  return (
    <div>
      <DashboardTemplate>
        <div></div>
      </DashboardTemplate>
    </div>
  );
}

export default HomePage;
