import DashboardTemplate from "../../Templates/DashboardTemplate/DashboardTemplate";
import PageTrackerTemplate from "../../Templates/PageTrackerTemplate/PageTrackerTemplate";
import MenuTemplate from "../../Templates/MenuTemplate/MenuTemplate";
// import SubjectDropDown from "../../components/common/SubjectDropDown/SubjectDropDown";
// import CustomDatePicker from "../../components/Date/CustomDatePicker";
// import Button from "../../components/common/Button/Button";
function ReportPage() {
  // const items = ["Item 1", "Item 2", "Item 3", "Item 4"];
  // const months = [
  //   "January",
  //   "February",
  //   "March",
  //   "April",
  //   "May",
  //   "June",
  //   "July",
  //   "August",
  //   "September",
  //   "October",
  //   "November",
  //   "December",
  // ];
  // const startYear = 2000;
  // const endYear = 2023;
  // const years = Array.from(
  //   { length: endYear - startYear + 1 },
  //   (_, index) => startYear + index
  // );
  return (
    <div>
      <DashboardTemplate>
        <PageTrackerTemplate>
          <MenuTemplate>
            {/* <SubjectDropDown upper={"Subject"} items={items} />
            <SubjectDropDown upper={"Section"} items={items} />
            <SubjectDropDown upper={"Month"} items={months} />
            <SubjectDropDown upper={"Year"} items={years} /> */}
            {/* <Button name={"Generate Report"} /> */}
          </MenuTemplate>
        </PageTrackerTemplate>
      </DashboardTemplate>
    </div>
  );
}

export default ReportPage;
