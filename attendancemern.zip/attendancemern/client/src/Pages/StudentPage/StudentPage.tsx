import DashboardTemplate from "../../Templates/DashboardTemplate/DashboardTemplate";
import PageTrackerTemplate from "../../Templates/PageTrackerTemplate/PageTrackerTemplate";
import InputNewStudent from "../../components/InputNewStudent/InputNewStudent";
// import MenuTemplate from "../../Templates/MenuTemplate/MenuTemplate";
// import SubjectDropDown from "../../components/common/SubjectDropDown/SubjectDropDown";
// import CustomDatePicker from "../../components/Date/CustomDatePicker";
// import Button from "../../components/common/Button/Button";
function StudentPage() {
  // const items = ["Item 1", "Item 2", "Item 3", "Item 4"];

  return (
    <div>
      <DashboardTemplate>
        <PageTrackerTemplate>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: "100%",
            }}
          >
            <InputNewStudent />
          </div>
        </PageTrackerTemplate>
      </DashboardTemplate>
    </div>
  );
}

export default StudentPage;
