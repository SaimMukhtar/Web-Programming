import DashboardTemplate from "../../Templates/DashboardTemplate/DashboardTemplate";
import PageTrackerTemplate from "../../Templates/PageTrackerTemplate/PageTrackerTemplate";

// import Button from "../../components/common/Button/Button";
function DashBoardPage() {
  return (
    <div>
      <DashboardTemplate>
        <PageTrackerTemplate>
          <div style={{ display: "flex", gap: 30 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 30 }}>
              <div style={{ display: "flex", gap: 30 }}>
                <div style={{ backgroundColor: "white" }}>
                  <img src="./images/dashboard-present.png" />
                </div>
                <div style={{ backgroundColor: "white" }}>
                  <img src="./images/dashboard-absent.png" />
                </div>
                <div style={{ backgroundColor: "white" }}>
                  <img src="./images/dashboard-attendance.png" />
                </div>
              </div>
              <div style={{ backgroundColor: "white", height: 200 }}>
                <img src="./images/dashboard-chart.png" />
              </div>
            </div>
            <div style={{ backgroundColor: "white" }}>
              <img src="./images/dashboard-spending.png" alt="img" />
            </div>
          </div>
        </PageTrackerTemplate>
      </DashboardTemplate>
    </div>
  );
}

export default DashBoardPage;
