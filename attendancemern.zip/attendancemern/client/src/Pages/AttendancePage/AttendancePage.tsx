import DashboardTemplate from "../../Templates/DashboardTemplate/DashboardTemplate";
import PageTrackerTemplate from "../../Templates/PageTrackerTemplate/PageTrackerTemplate";
import MenuTemplate from "../../Templates/MenuTemplate/MenuTemplate";
import SubjectDropDown from "../../components/common/SubjectDropDown/SubjectDropDown";
import CustomDatePicker from "../../components/Date/CustomDatePicker";
import Button from "../../components/common/Button/Button";
import { Link, Outlet } from "react-router-dom";
import { useState } from "react";
import { useAppSelector, useAppDispatch } from "../../redux/Store";
import { DataType, getData } from "../../redux/StudentDataSlice";
import { getDataAttendance } from "../../redux/StudentAttendanceMarkSlice";
// import {getdate} from "../../redux/DateValueSlice"

type NewDataType = {
  _id: string;
  name: string;
};
function AttendancePage() {
  const dispatch = useAppDispatch();
  const [selectedSubjectValue, setSelectedSubjectValue] = useState("");
  const [selectedSectionValue, setSelectedSectionValue] = useState("");
  const date = useAppSelector((state) => state.reducedateValue.dateValue);

  const section = ["select", "A", "B", "C", "D"];
  const subject = ["select", "computer", "oop", "Ai", "coal"];

  const handleClickButton = async () => {
    try {
      const response = await fetch(
        "http://localhost:3000/data/dataStudentGrab",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            subject: selectedSubjectValue,
            section: selectedSectionValue,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to save todo item");
      }

      const data: DataType[] = await response.json();
      // console.log("got data:", data);
      dispatch(getData(data));
      const newData =
        data &&
        data.length > 0 &&
        data?.map((item) => ({
          ...item,
          mark: false,
          date: date,
        }));

      const newDataData = newData.map(
        ({ _id, name, ...rest }: NewDataType) => ({
          id: _id, // Assign _id to id
          ...rest,
        })
      );
      console.log("the new data that was copied: ", newDataData);

      dispatch(getDataAttendance(newDataData));
      // console.log(newData);
    } catch (error) {
      console.error("Error saving todo:", error);
    }
  };
  return (
    <div>
      <DashboardTemplate>
        <PageTrackerTemplate>
          <MenuTemplate>
            <SubjectDropDown
              upper={"Subject"}
              items={subject}
              setSelectedValue={setSelectedSubjectValue}
            />
            <SubjectDropDown
              upper={"Section"}
              items={section}
              setSelectedValue={setSelectedSectionValue}
            />
            <CustomDatePicker upper={"Date"} />
            <nav>
              <Link to="Sheet">
                <div onClick={handleClickButton}>
                  <Button name={"Generate Sheet"} />
                </div>
              </Link>
            </nav>
          </MenuTemplate>

          <Outlet />
        </PageTrackerTemplate>
      </DashboardTemplate>
    </div>
  );
}

export default AttendancePage;
