import { createSlice, PayloadAction } from "@reduxjs/toolkit";



type TInitialState = {
    dateValue: string
}

const initialState: TInitialState =  {
    dateValue: "",
};

const DateValueSlice = createSlice({
  name: "dateValue",
  initialState,
  reducers: {
    getdate: (state, action: PayloadAction<string>) => {
      state.dateValue = action.payload
    },
  },
});

export default DateValueSlice.reducer;
export const { getdate } = DateValueSlice.actions;
