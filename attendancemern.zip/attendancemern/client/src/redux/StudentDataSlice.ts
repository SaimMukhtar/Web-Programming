import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export type DataType = {
    name:string,
    subject:string,
    section:string,
    id:string,
}

type TInitialState = {
    studentData: DataType[]
}

const initialState: TInitialState =  {
    studentData: [],
};

const StudentDataSlice = createSlice({
  name: "StudentData",
  initialState,
  reducers: {
    getData: (state, action: PayloadAction<DataType[]>) => {
      state.studentData = action.payload
    },
  },
});

export default StudentDataSlice.reducer;
export const { getData } = StudentDataSlice.actions;
