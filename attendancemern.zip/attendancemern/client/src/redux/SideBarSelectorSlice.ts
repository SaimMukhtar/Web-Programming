import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type SideBarState = {
  SideBarName: TSidebarName;
};

export type TSidebarName =   | "Attendance"
  | "Dashboard"
  | "Report"
  | "Student"
  | "Logout"
  | "test"
  | null

// Define the type for the payload action
// type SideBarNameType = {
//   SideBarName:   | "Attendance"
//   | "Dashboard"
//   | "Report"
//   | "Student"
//   | "Logout"
//   | "test"
//   | null;
// };

const initialState: SideBarState = {
  SideBarName: null,
};

const SideBarSelectorSlice = createSlice({
  name: "SideBarName",
  initialState,
  reducers: {
    changeName: (state, action: PayloadAction<TSidebarName>) => {
      state.SideBarName = action.payload
    },
  },
});

export default SideBarSelectorSlice.reducer;
export const { changeName } = SideBarSelectorSlice.actions;
