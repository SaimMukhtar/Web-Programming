import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type DataType = {
    subject:string,
    section:string,
    id:string,
    mark:boolean
    date:Date
}

type TInitialState = {
    studentDataAttendace: DataType[]
}

const initialState: TInitialState =  {
    studentDataAttendace: [],
};

const StudentAttendanceMarkSlice = createSlice({
  name: "StudentData",
  initialState,
  reducers: {
    getDataAttendance: (state, action: PayloadAction<DataType[]>) => {
      state.studentDataAttendace = action.payload
    },
    checkMark: (state, action: PayloadAction<string>) => {
        action.payload
         const objWithIdIndex = state.studentDataAttendace.findIndex((obj) => obj.id === action.payload); 
         state.studentDataAttendace[objWithIdIndex].mark = !state.studentDataAttendace[objWithIdIndex].mark
    },
  },
});

export default StudentAttendanceMarkSlice.reducer;
export const { getDataAttendance,checkMark } = StudentAttendanceMarkSlice.actions;
