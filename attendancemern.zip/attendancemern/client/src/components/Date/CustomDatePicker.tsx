import { useState } from "react";
import "react-datepicker/dist/react-datepicker.css";
import DatePicker from "react-multi-date-picker";
import type { Value } from "react-multi-date-picker";
import "./styleDate.css";
import { useAppDispatch } from "../../redux/Store";
import { getdate } from "../../redux/DateValueSlice";

const CustomDatePicker = ({ upper }: { upper: string }) => {
  const dispatch = useAppDispatch();
  const [startDate, setStartDate] = useState<Value>(null);

  const handleDateChange = (date: Value) => {
    // Handle the null case separately
    if (date !== null) {
      // console.log(date.format("DD/MM/YYYY"));
      setStartDate(date);
      dispatch(getdate(date.format("DD/MM/YYYY")));
    }
  };

  return (
    <div className="hello">
      <DatePicker
        value={startDate}
        containerStyle={{
          width: "100%",
        }}
        inputClass="custom-input"
        className="custom-calendar"
        onChange={(date) => handleDateChange(date)}
      />
      <div className="dateTitle">{upper}</div>
      <img src="/images/dropdown-icon.png" className="imageDropDown" />
    </div>
  );
};

export default CustomDatePicker;
