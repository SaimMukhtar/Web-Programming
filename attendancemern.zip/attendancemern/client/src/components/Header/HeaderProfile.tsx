import styles from "./HeaderProfile.module.css";
function HeaderProfile({ name }: { name: string }) {
  return (
    <div className={styles.profile}>
      <div className={styles.profilePicture}>
        {/* this is yet to be implemented */}
        {/* <img src="" alt="person" /> */}
      </div>
      <div className={styles.nameDiv}>{name}</div>
    </div>
  );
}

export default HeaderProfile;
