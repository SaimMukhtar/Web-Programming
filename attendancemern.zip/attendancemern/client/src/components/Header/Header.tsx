import styles from "./Header.module.css";
import HeaderContent from "./HeaderContent";
function Header() {
  return (
    <div className={styles.header}>
      <div className={styles.HeaderContentContainer}>
        <div className={styles.headerTitle}>Attendify</div>
        <HeaderContent />
      </div>
    </div>
  );
}

export default Header;
