import styles from "./Header.module.css";
function HeaderLogin() {
  return (
    <div className={styles.header}>
      <div className={styles.HeaderContentContainer}>
        <div className={styles.headerTitle}>Attendify</div>
      </div>
    </div>
  );
}

export default HeaderLogin;
