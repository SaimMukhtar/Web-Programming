import HeaderProfile from "./HeaderProfile";
import styles from "./HeaderContent.module.css";
function HeaderContent() {
  return (
    <div className={styles.icons}>
      {" "}
      <img src="/images/message-icon.png" alt="inbox" />
      <img src="/images/notification-icon.png" alt="notification" />
      <HeaderProfile name={"Aalee"} />
    </div>
  );
}

export default HeaderContent;
