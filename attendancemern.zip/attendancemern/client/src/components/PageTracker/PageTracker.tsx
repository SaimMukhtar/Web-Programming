import styles from "./PageTracker.module.css";
import { useAppSelector } from "../../redux/Store";

function PageTracker() {
  let { value1 = "", value2 = "", value3 = "" } = {};

  const status = useAppSelector(
    (state) => state.reduceSideBarSelector.SideBarName
  );

  if (status == "Attendance") {
    value1 = "Attendance";
    value2 = "Track";
    value3 = "Attendance";
  } else if (status == "Dashboard") {
    value1 = "Dashboard";
    value2 = "Analyze";
    value3 = "Dashboard";
  } else if (status == "Report") {
    value1 = "Report";
    value2 = "Analyze";
    value3 = "Report";
  } else if (status == "Student") {
    value1 = "Student";
    value2 = "Student";
    value3 = "Student";
  } else {
    value1 = "";
    value2 = "";
    value3 = "";
  }
  return (
    <div className={styles.trackerContainer}>
      <div className={styles.f1Div}>{value1}</div>
      <div className={styles.lowerf1}>
        <div className={styles.f2Div}>{value2} / </div>
        <div className={styles.f3Div}>{value3}</div>
      </div>
    </div>
  );
}

export default PageTracker;
