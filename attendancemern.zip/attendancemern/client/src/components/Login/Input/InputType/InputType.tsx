import styles from "./InputType.module.css";

function InputType({ user }: { user: string }) {
  return <div className={styles.inputType}>{user}</div>;
}

export default InputType;
