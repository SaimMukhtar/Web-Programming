import styles from "./InputBox.module.css";

type inputBoxProp = {
  value: string;
  setData: React.Dispatch<string>;
};

function InputBox({ value, setData }: inputBoxProp) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setData(e.target.value);
  };
  return (
    <div className={styles.inputBox}>
      <input type={value} onChange={handleChange} />
    </div>
  );
}

export default InputBox;
