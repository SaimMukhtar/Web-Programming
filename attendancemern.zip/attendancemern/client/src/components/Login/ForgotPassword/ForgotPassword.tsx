import styles from "./ForgotPassword.module.css";
function ForgotPassword() {
  return <div className={styles.forgotPassword}>Forgot password?</div>;
}

export default ForgotPassword;
