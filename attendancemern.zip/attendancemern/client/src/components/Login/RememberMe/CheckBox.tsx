import { useState } from "react";
import styles from "./CheckBox.module.css"; // Import the CSS module

function CheckBox() {
  const [isChecked, setIsChecked] = useState(true);

  const handleCheckboxChange = () => {
    setIsChecked((prevState) => !prevState);
  };

  return (
    <div>
      <label className={styles.container}>
        <input
          type="checkbox"
          checked={isChecked}
          onChange={handleCheckboxChange}
        />
        <span className={styles.checkmark}></span>
      </label>
    </div>
  );
}

export default CheckBox;
