import styles from "./RememberMe.module.css";

function RememberMe() {
  return <div className={styles.remember}>Remember me</div>;
}

export default RememberMe;
