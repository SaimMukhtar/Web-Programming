import styles from "./LoginForm.module.css";
import UserButton from "../UserButton/UserButton";
import InputType from "../Input/InputType/InputType";
import InputBox from "../Input/InputBox/InputBox";
import CheckBox from "../RememberMe/CheckBox";
import RememberMe from "../RememberMe/RememberMe";
import SignIn from "../SignIn/SignIn";
import ForgotPassword from "../ForgotPassword/ForgotPassword";
import RegisterText from "../Register/RegisterText";
import RegisterButton from "../Register/RegisterButton";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

// {
//         method: "GET",

//         body: JSON.stringify({
//           username: userValue, // Keep the original title (you can update this as per your requirement)
//           password: userPassValue,
//         }),
//       });

function LoginForm() {
  const navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleClick = async (userValue: string, userPassValue: string) => {
    console.log("username: ", userValue);
    console.log("password: ", userPassValue);

    try {
      const response = await fetch("http://localhost:3000/data/dataCheck/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username: userValue, password: userPassValue }),
      });

      if (!response.ok) {
        throw new Error("Failed to login try again");
      }

      const data = await response.json();
      if (data == true) {
        console.log("login Sucessful: ", data);
        navigate("/home");
      } else {
        setErrorMessage("Username or password were wrong please enter again");
      }
    } catch (error) {
      setErrorMessage("Username or password were wrong please enter again");
      console.error("Username or password were wrong:", error);
    }
  };

  return (
    <div className={styles.formBody}>
      <div className={styles.userbuttons}>
        <div>
          <UserButton name={"Admin"} />
        </div>
        <div className={styles.adminButton}>
          <UserButton name={"Teacher"} />
        </div>
      </div>
      <div className={styles.userData}>
        <InputType user={"Username"} />
        <InputBox value={"text"} setData={setUsername} />
      </div>
      <div>
        <InputType user={"Password"} />
        <InputBox value={"password"} setData={setPassword} />
      </div>
      <div>
        <CheckBox />
        <RememberMe />
      </div>
      <div>
        {errorMessage && (
          <div className={styles.errorMessage}>
            {errorMessage}
            <button
              className={styles.closeButton}
              onClick={() => setErrorMessage(null)}
            >
              Close
            </button>
          </div>
        )}
        <SignIn onClick={handleClick} username={username} password={password} />
      </div>
      <div>
        <ForgotPassword />
      </div>
      <div className={styles.register}>
        <RegisterText />
        <div className={styles.registerButton}>
          <RegisterButton />
        </div>
      </div>
    </div>
  );
}

export default LoginForm;
