import styles from "./SignIn.module.css";

type SignInProp = {
  onClick: (username: string, password: string) => void;
  username: string;
  password: string;
};

function SignIn({ onClick, username, password }: SignInProp) {
  const handleClick = () => {
    // console.log(username);
    // console.log(password);

    onClick(username, password);
  };

  return (
    <div onClick={handleClick}>
      <div className={styles.container}>Sign in</div>
    </div>
  );
}

export default SignIn;
