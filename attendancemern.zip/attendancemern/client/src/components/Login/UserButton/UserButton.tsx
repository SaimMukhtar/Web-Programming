import styles from "./UserButton.module.css";

type PropName = {
  name: string;
};
function UserButton({ name }: PropName) {
  return (
    <div className={styles.buttonContainer}>
      <div className={styles.radioContainer}>
        <input type="radio" name="radio" />
        <div className={styles.checkmark}></div>
      </div>
      <div className={styles.buttonName}>{name}</div>
    </div>
  );
}

export default UserButton;
