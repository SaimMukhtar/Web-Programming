import styles from "./RegisterText.module.css";
function RegisterText() {
  return <div className={styles.text}>Don't have an account? </div>;
}

export default RegisterText;
