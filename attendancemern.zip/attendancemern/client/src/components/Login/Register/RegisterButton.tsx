import styles from "./RegisterButton.module.css";
import React, { useState } from "react";
import "react-responsive-modal/styles.css";
import { Modal } from "react-responsive-modal";
import "./modal.css";
function RegisterButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentUsername, setCurrentUsername] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");

  const handleOpenModal = () => {
    setIsOpen(true);
  };

  const handleCloseModal = async () => {
    // onEditClick(id, currentTitle); // Pass id and currentTitle as separate arguments
    setIsOpen(false);
    try {
      const response = await fetch("http://localhost:3000/data/dataSend/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: currentUsername,
          password: currentPassword,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to save todo item");
      }

      const data = await response.json();
      console.log("New user:", data.username);
    } catch (error) {
      console.error("Error saving todo:", error);
    }
  };

  const handleChangeValueUsername = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setCurrentUsername(e.target.value);
    // console.log(currentUsername);
  };
  const handleChangeValuePassword = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setCurrentPassword(e.target.value);
    // console.log(currentPassword);
  };
  // const handleClick = () => {};
  return (
    <div>
      <div className={styles.button} onClick={handleOpenModal}>
        Register here
      </div>
      <Modal
        open={isOpen}
        onClose={handleCloseModal}
        classNames={{
          overlay: "customOverlay",
          modal: "customModal",
        }}
      >
        <h2 className={styles.customModalHeader}>Create New User</h2>
        <div className={styles.inputContainer}>
          <div className={styles.username}>
            <p>Username: </p>
            <input
              className={styles.customInput}
              type="text"
              onChange={handleChangeValueUsername}
            />
          </div>
          <div className={styles.password}>
            <p>Password: </p>
            <input
              className={styles.customInput}
              type="text"
              // value={currentTitle}
              onChange={handleChangeValuePassword}
            />
          </div>
        </div>
        <button className={styles.customButton} onClick={handleCloseModal}>
          Submit
        </button>
      </Modal>
    </div>
  );
}

export default RegisterButton;
