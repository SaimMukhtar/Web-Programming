import styles from "./InputNewStudent.module.css";
import { useState } from "react";
import { v4 as uuidv4 } from "uuid";

// type inputDataType = {
//   name: string;
//   subject: string;
//   section: string;
// };
function InputNewStudent() {
  const [inputDataName, setInputDataName] = useState("");
  const [inputDataSection, setInputDataSection] = useState("");
  const [inputDataSubject, setInputDataSubject] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = async () => {
    await setIsFocused(true);
    const id = uuidv4() as string;
    try {
      const response = await fetch(
        "http://localhost:3000/data/dataSendStudent/",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            id: id,
            name: inputDataName,
            section: inputDataSection,
            subject: inputDataSubject,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to save todo item");
      }

      const data = await response.json();
      console.log("New user:", data.name);
    } catch (error) {
      console.error("Error saving todo:", error);
    }
  };

  const handleBlur = () => {
    setIsFocused(false);
  };
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputDataName(e.target.value);
  };

  const handleSectionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputDataSection(e.target.value);
  };

  const handleSubjectChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputDataSubject(e.target.value);
  };

  return (
    <div>
      <div className={styles.studentFormTitle}>Enter a new Student</div>
      <div className={styles.studentFormContainer}>
        <div className={styles.studentInputNameContainer}>
          <div className={styles.studentNameText}>Student Name: </div>
          <input
            type="text"
            placeholder="Enter the Name.."
            onChange={handleNameChange}
          />
        </div>
        <div className={styles.studentInputNameContainer}>
          <div className={styles.studentNameText}>Student Section: </div>
          <input
            type="text"
            placeholder="Enter the Section.."
            onChange={handleSectionChange}
          />
        </div>
        <div className={styles.studentInputNameContainer}>
          <div className={styles.studentNameText}>Student Subject: </div>
          <input
            type="text"
            placeholder="Enter the Section.."
            onChange={handleSubjectChange}
          />
        </div>
        <div className={styles.submitButton}>
          <button
            className={`${styles.buttonContainer} ${
              isFocused ? styles.focus : ""
            }`}
            onClick={handleFocus}
            onBlur={handleBlur}
            tabIndex={0}
          >
            submit
          </button>
        </div>
      </div>
    </div>
  );
}

export default InputNewStudent;
