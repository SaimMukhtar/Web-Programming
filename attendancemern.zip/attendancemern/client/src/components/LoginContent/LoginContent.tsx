import styles from "./LoginContent.module.css";

function LoginContent() {
  return (
    <div className={styles.loginContentContainer}>
      <div>
        <div className={styles.attendanceDiv}>Attendance</div>
        <div className={styles.attendanceSubDiv}>for your business</div>
      </div>
      <div className={styles.loginContentText}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, itaque
        accusantium odio, soluta, corrupti aliquam quibusdam tempora at
        cupiditate quis eum maiores libero veritatis? Dicta facilis sint aliquid
        ipsum atque?
      </div>
    </div>
  );
}

export default LoginContent;
