import Button from "../common/Button/Button";
import styles from "./AttendanceSheet.module.css";
import { changeName } from "../../redux/SideBarSelectorSlice";
import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../redux/Store";
// import { useState } from "react";
import { checkMark } from "../../redux/StudentAttendanceMarkSlice";

function AttendanceSheet() {
  const data = useAppSelector((state) => state.reduceStudentData.studentData);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const check = useAppSelector(
    (state) => state.reducestudentDataAttendace.studentDataAttendace
  );
  const handleCheckboxChange = (index: string) => {
    console.log("index", index);
    dispatch(checkMark(index));
  };

  const columns = ["#", "status", "Student Name", "Student ID"];

  const handleClick = async () => {
    try {
      console.log("this is the data right before sending to database:", check);

      const response = await fetch(
        "http://localhost:3000/data/dataSendStudentAttendance/",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ updatedData: check }),
        }
      );
      const data = await response.json();
      console.log(data);
      if (response.ok) {
        console.log("Data sent successfully");
      } else {
        console.error("Error sending data");
      }
    } catch (error) {
      console.error("Error sending data:", error);
    }
    dispatch(changeName(null));
    navigate("/home");
    console.log(check);
  };

  return (
    <div>
      <div className={styles.attendanceFormContainer}>
        <div className={styles.attendanceFormSubContainer}>
          <div className={styles.attendanceSheetHeading}>Attendance Sheet</div>
          <table className={styles.table}>
            <thead>
              <tr>
                {columns.map((column) => (
                  <th key={column}>{column}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data &&
                data.length > 0 &&
                data?.map((row, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>
                      <input
                        type="checkbox"
                        checked={check[index].mark}
                        onChange={() => handleCheckboxChange(data[index].id)}
                      />
                    </td>
                    <td>{row.name}</td>
                    <td>{row.id}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
      <div onClick={handleClick}>
        <Button name={"Submit"} />
      </div>
    </div>
  );
}

export default AttendanceSheet;
