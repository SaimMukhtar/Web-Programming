import { useState } from "react";
import styles from "./Button.module.css";

type ButtonProp = {
  name: string;
  // onClick: React.MouseEventHandler<HTMLDivElement>;
};

function Button({ name }: ButtonProp) {
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  return (
    <div>
      <div
        className={`${styles.buttonContainer} ${isFocused ? styles.focus : ""}`}
        onClick={handleFocus}
        onBlur={handleBlur}
        tabIndex={0}
      >
        {name}
      </div>
    </div>
  );
}

export default Button;
