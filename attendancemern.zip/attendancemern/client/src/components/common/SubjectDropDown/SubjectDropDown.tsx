// import { useState } from "react";
import styles from "./SubjectDropDown.module.css";
type SubjectDropDownProp = {
  upper: string;
  items: string[] | number[];
  setSelectedValue: React.Dispatch<React.SetStateAction<string>>;
};
function SubjectDropDown({
  upper,
  items,
  setSelectedValue,
}: SubjectDropDownProp) {
  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    console.log(e.target.value);

    setSelectedValue(e.target.value);
  };
  return (
    <div>
      <div className={styles.customDropdown}>
        <select
          style={{ position: "absolute", zIndex: 10 }}
          onChange={handleSelectChange}
        >
          {items.map((item, index) => (
            <option key={index}>{item}</option>
          ))}

          {/* <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option> */}
        </select>
        <img src="/images/dropdown-icon.png" alt="arrow" />
        <div className={styles.subject}>{upper}</div>
      </div>
    </div>
  );
}

export default SubjectDropDown;
