import styles from "./SideBar.module.css";
import SideBarContent from "./SideBarContent";

function SideBar() {
  return (
    <div className={styles.sidebar}>
      {" "}
      <SideBarContent />
    </div>
  );
}

export default SideBar;
