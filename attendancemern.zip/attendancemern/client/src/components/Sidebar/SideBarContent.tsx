// import { useEffect } from "react";
import styles from "./SideBarContent.module.css";
import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../redux/Store";
import { TSidebarName, changeName } from "../../redux/SideBarSelectorSlice";

function SideBarContent() {
  const status = useAppSelector(
    (state) => state.reduceSideBarSelector.SideBarName
  );
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleItemClick = (item: TSidebarName) => {
    if (item == "Logout") {
      console.log("i was triggered");
      dispatch(changeName(null));
      navigate("/");
    } else {
      dispatch(changeName(item));
      navigate("/" + item);
    }
    console.log(location.pathname);
  };

  return (
    <div className={styles.contentContainer}>
      <div className={styles.sideBarCategories}>Track</div>
      <a
        className={`${styles.sideBarCategorieslist} ${
          status === "Attendance" ? styles.focus : ""
        }`}
        onClick={() => {
          handleItemClick("Attendance");
        }}
      >
        <div>
          <img src="/images/spreadsheet-icon.png" alt="Spreadsheet Icon" />
        </div>
        <div className={styles.sideBarSubCategories}>Attendance Sheet</div>
      </a>
      <div className={styles.sideBarCategories}>Analyze</div>
      <div
        className={`${styles.sideBarCategorieslist} ${
          status === "Dashboard" ? styles.focus : ""
        }`}
        onClick={() => handleItemClick("Dashboard")}
      >
        <div>
          <img src="/images/chart-icon.png" alt="Chart Icon" />
        </div>
        <div className={styles.sideBarSubCategories}>Dashboard</div>
      </div>
      <div
        className={`${styles.sideBarCategorieslist} ${
          status === "Report" ? styles.focus : ""
        }`}
        onClick={() => handleItemClick("Report")}
      >
        <div>
          <img src="/images/report-icon.png" alt="Report Icon" />
        </div>
        <div className={styles.sideBarSubCategories}>Report</div>
      </div>
      <div className={styles.sideBarCategories}>Manage</div>
      <div
        className={`${styles.sideBarCategorieslist} ${
          status === "Student" ? styles.focus : ""
        }`}
        onClick={() => handleItemClick("Student")}
      >
        <div>
          <img src="/images/student-icon.png" alt="Student Icon" />
        </div>
        <div className={styles.sideBarSubCategories}>Student</div>
      </div>
      <div
        className={`${styles.sideBarCategorieslist} ${
          status === "Logout" ? styles.focus : ""
        }`}
        onClick={() => handleItemClick("Logout")}
      >
        <div>
          <img src="/images/logout-icon.png" alt="Logout Icon" />
        </div>
        <div className={styles.sideBarSubCategories}>Logout</div>
      </div>
      <div
        className={`${styles.sideBarCategorieslist} ${
          status === "test" ? styles.focus : ""
        }`}
        onClick={() => handleItemClick("test")}
      >
        <div>
          <img src="/images/logout-icon.png" alt="Logout Icon" />
        </div>
        <div className={styles.sideBarSubCategories}>test</div>
      </div>
    </div>
  );
}

export default SideBarContent;
