import "./App.css";
import { Routes, Route } from "react-router-dom";
import LoginPage from "./Pages/LoginPage/LoginPage";
import HomePage from "./Pages/HomePage/HomePage";
import AttendancePage from "./Pages/AttendancePage/AttendancePage";
import DashBoardPage from "./Pages/DashBoardPage/DashBoardPage";
import ReportPage from "./Pages/ReportPage/ReportPage";
import StudentPage from "./Pages/StudentPage/StudentPage";
import Test from "./Pages/Test/Test";
import AttendanceSheet from "./components/AttendanceSheet/AttendanceSheet";
// import Button from "./components/common/Button/Button";
// import SubjectDropDown from "./components/common/SubjectDropDown/SubjectDropDown";
// import CustomDatePicker from "./components/Date/CustomDatePicker";
// import PageTracker from "./components/PageTracker/PageTracker";
// import LoginContent from "./components/LoginContent/LoginContent";
// import Testing from "./components/Testing";
// import { XTemplate } from "./components/XTemplate";
// import DashboardTemplate from "./Templates/DashboardTemplate/DashboardTemplate";
// import MenuTemplate from "./Templates/MenuTemplate/MenuTemplate";

function App() {
  // const items = ["Item 1", "Item 2", "Item 3", "Item 4"];
  return (
    <div>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/Attendance" element={<AttendancePage />}>
          <Route path="Sheet" element={<AttendanceSheet />} />
        </Route>
        <Route path="/Dashboard" element={<DashBoardPage />} />
        <Route path="/Report" element={<ReportPage />} />
        <Route path="/Student" element={<StudentPage />} />
        <Route path="/test" element={<Test />}>
          <Route path="Sheet" element={<AttendanceSheet />} />
        </Route>
      </Routes>
      {/* <DashboardTemplate>
        {" "}
        <div style={{ display: "flex", flexDirection: "column" }}>
          <PageTracker f1={"attendance"} f2={"attendance"} f3={"attendance"} />
          <MenuTemplate>
            {" "}
            <SubjectDropDown upper={"Subject"} items={items} />
            <SubjectDropDown upper={"Section"} items={items} />
            <CustomDatePicker upper={"Date"} />
            <Button name={"Generate Sheet"} />
          </MenuTemplate>
        </div>
      </DashboardTemplate> */}
    </div>
  );
}

export default App;
