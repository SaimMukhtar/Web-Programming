import React from "react";
import PageTracker from "../../components/PageTracker/PageTracker";
import styles from "./PageTrackerTemplate.module.css";

function PageTrackerTemplate({ children }: { children: React.ReactNode }) {
  return (
    <div className={styles.TrackerContainer}>
      <PageTracker />
      {children}
    </div>
  );
}

export default PageTrackerTemplate;
