import styles from "./MenuTemplate.module.css";
function MenuTemplate({ children }: { children: React.ReactNode }) {
  return <div className={styles.menuBar}> {children}</div>;
}

export default MenuTemplate;
