import Header from "../../components/Header/Header";
import SideBar from "../../components/Sidebar/SideBar";
function DashboardTemplate({ children }: { children: React.ReactNode }) {
  return (
    <div>
      <Header />
      <div style={{ display: "flex" }}>
        <SideBar />
        {children}
      </div>
    </div>
  );
}

export default DashboardTemplate;
