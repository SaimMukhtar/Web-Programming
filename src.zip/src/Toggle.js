
import React, { useState, useEffect } from 'react';
import './Toggle.css'; 

const Toggle = () => {
    const [isDarkMode, setIsDarkMode] = useState(false);

    useEffect(() => {
        document.body.classList.toggle('dark-mode', isDarkMode);
    }, [isDarkMode]);

    const toggleMode = () => {
        setIsDarkMode(prevMode => !prevMode);
    };

    return (
        <div className="toggle-container">
            <h1>{isDarkMode ? 'Dark Mode' : 'Light Mode'}</h1>
            <button onClick={toggleMode}>
                Toggle to {isDarkMode ? 'Light' : 'Dark'} Mode
            </button>
        </div>
    );
};

export default Toggle;
