
import React from 'react';
import Toggle from './Toggle.js';

const App = () => {
    return (
        <div className="App">
            <Toggle />
        </div>
    );
};

export default App;
